//ATAN_LUT.H



#ifndef ATAN_LUT_H
#define ATAN_LUT_H


float atan_table(float x);


#endif
